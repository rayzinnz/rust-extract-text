https://tauri.app/start/


--first app

**start new app**

```shell
cd C:\Users\hrag\Sync\Programming\tauri
npm create tauri-app@latest

cd appname
npm install
```



**dev**

```shell
npm run tauri dev

or

WEBKIT_DISABLE_DMABUF_RENDERER=1 npm run tauri dev
WEBKIT_DISABLE_COMPOSITING_MODE=1 npm run tauri dev
```

**compile**
```shell
npm run tauri build
```

**debugging**
https://tauri.app/develop/debug/vscode/
